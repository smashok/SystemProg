// helloword.cpp
#include <iostream>

int main() {

    int myVarible = 5;
        int rand;
    std::cout<<myVarible<<" "<<rand<<'\n';
    return 0;
}